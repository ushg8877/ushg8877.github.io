第二题

在 solution.cpp 中实现 int add(int x, int y)，不要编写 main。
将 solution.cpp 和 grader.cpp 放在同一个文件夹，使用 C++17 编译：

g++ -O2 -std=c++17 grader.cpp solution.cpp -o grader

Windows PowerShell 运行：
  .\grader.exe

Linux / macOS 运行：
  ./grader

不需要输入文件。grader 会自动生成 5000 万组测试，包含 0 和 10^9 等边界。
检查进度、Accepted / Wrong answer 显示在标准错误；通过后标准输出是一行验证码。
将这一行填入《第二题》网页的谜底框。

grader.cpp 自带加密实现，无需安装 OpenSSL 或其他额外库。
其中 Monocypher 4.0.3 的源码保留原作者版权和 BSD-2-Clause / CC0 许可证。
